function hide (id) {
    document.querySelector(id).remove();
}