function addLike () {
    var element = document.querySelector('span');
    element.innerText++;
}