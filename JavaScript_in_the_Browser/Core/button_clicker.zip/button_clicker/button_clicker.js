function logOut (element) {
    element.innerText = "Logout";
}

function definitionAdded (element) {
    element.remove();
}