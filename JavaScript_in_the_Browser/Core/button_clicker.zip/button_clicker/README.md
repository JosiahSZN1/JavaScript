#   Button Clicker

This is a readme for JavaScript, JavaScript in the Browser core assignment 'Button Clicker.'

Objectives
Practice using the onclick event
Combine what we've learned of HTML, CSS and JS
Recreate the layout you see below. It may be helpful to focus on getting the HTML and CSS completed before adding the JS functionality to the page.

https://s3.us-east-1.amazonaws.com/General_V88/boomyeah2015/codingdojo/curriculum/content/chapter/1623967324__dojonary.png